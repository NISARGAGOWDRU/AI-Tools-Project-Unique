class Retrieval:
    collection_id, collection_name, record_id, chunk_id = "DbgY9Za77t97CC9R4p8Zqkej", "UntitledCollection", "qpEaN1xDWvYSYa5mhzAYTsJf", "LmK0UOQC6orkr1lFNnDrrKOh"
