class Assistant:
    chat_completion_model_id, assistant_id, assistant_name, chat_id, message_id = (
        "TpUiB8O4",
        "X5lMFP15jqRnjPQ4WE1YQ36Q",
        "UntitledAssistant",
        "SdELe57d8rxBsCBuRrWcUJw0",
        "SdELe57d8rxBsCBuRrWcUJw0",
    )
    assistant_ids = []
