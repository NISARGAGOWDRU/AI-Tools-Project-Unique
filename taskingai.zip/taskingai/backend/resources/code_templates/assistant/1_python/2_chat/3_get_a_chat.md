### Get a Chat

```python
import taskingai
from taskingai.assistant.chat import Chat

chat: Chat = taskingai.assistant.get_chat(
    assistant_id="$$ASSISTANT_ID$$",
    chat_id="$$CHAT_ID$$",
)
```
