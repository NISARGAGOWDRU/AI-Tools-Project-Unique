### Get an Assistant

```python
import taskingai
from taskingai.assistant import Assistant

assistant: Assistant = taskingai.assistant.get_assistant(
    assistant_id="$$ASSISTANT_ID$$"
)
```
