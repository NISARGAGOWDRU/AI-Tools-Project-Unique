### Delete a Chat

```python
import taskingai

await taskingai.assistant.a_delete_chat(
    assistant_id="$$ASSISTANT_ID$$",
    chat_id="$$CHAT_ID$$",
)
```
