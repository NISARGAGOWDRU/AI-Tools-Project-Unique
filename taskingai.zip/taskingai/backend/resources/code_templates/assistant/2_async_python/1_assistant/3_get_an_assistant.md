### Get an Assistant

```python
import taskingai
from taskingai.assistant import Assistant

assistant: Assistant = await taskingai.assistant.a_get_assistant(
    assistant_id="$$ASSISTANT_ID$$"
)
```
