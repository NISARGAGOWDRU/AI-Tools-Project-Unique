### Get a record

```python
import taskingai

record = taskingai.retrieval.get_record(
    collection_id="$$COLLECTION_ID$$",
    record_id="$$RECORD_ID$$"
)
```
