### Get a chunk

```python
import taskingai

chunk = taskingai.retrieval.get_chunk(
    collection_id="$$COLLECTION_ID$$",
    chunk_id="$$CHUNK_ID$$"
)

print(f"got chunk: {chunk}\n")
```
