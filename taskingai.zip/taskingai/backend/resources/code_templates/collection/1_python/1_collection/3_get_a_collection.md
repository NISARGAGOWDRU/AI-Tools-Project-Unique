### Get a collection

```python
import taskingai

collection = taskingai.retrieval.get_collection(
    collection_id="$$COLLECTION_ID$$"
)
```
