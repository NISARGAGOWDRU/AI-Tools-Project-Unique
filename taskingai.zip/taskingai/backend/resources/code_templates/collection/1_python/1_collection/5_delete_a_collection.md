### Delete a collection

```python
import taskingai

taskingai.retrieval.delete_collection(collection_id="$$COLLECTION_ID$$")
```

When executed, the specified collection is permanently removed from the project and the records and chunks associated with it are also deleted.
