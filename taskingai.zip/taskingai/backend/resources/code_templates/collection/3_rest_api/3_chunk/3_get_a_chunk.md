### Get a chunk

```bash
curl -X GET $$SERVICE_HOST$$/v1/collections/$$COLLECTION_ID$$/chunks/$$CHUNK_ID$$ \
     -H "Authorization: Bearer $$API_KEY$$" \
     -H "Content-Type: application/json"
```
