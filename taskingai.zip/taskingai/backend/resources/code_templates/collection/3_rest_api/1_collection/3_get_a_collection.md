### Get a collection

```bash
curl -X GET $$SERVICE_HOST$$/v1/collections/$$COLLECTION_ID$$ \
     -H "Authorization: Bearer $$API_KEY$$" \
     -H "Content-Type: application/json"
```
