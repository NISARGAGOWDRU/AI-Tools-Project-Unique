### Get a record

```python
import taskingai

record = await taskingai.retrieval.a_get_record(
    collection_id="$$COLLECTION_ID$$",
    record_id="$$RECORD_ID$$"
)
```
