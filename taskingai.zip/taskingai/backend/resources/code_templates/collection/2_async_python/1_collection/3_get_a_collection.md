### Get a collection

```python
import taskingai

collection = await taskingai.retrieval.a_get_collection(
    collection_id="$$COLLECTION_ID$$"
)
```
